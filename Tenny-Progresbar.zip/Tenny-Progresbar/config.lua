Config = {}

-- Tema isimleri (Renkler CSS'de tanımlı)
Config.Themes = {
    'default',  -- Yeşil (Varsayılan)
    'pink',     -- Pembe
    'blue',     -- Mavi
    'cyan',     -- Cyan
    'purple',   -- Mor
    'white',    -- Beyaz
    'red',      -- Kırmızı
    'orange',   -- Turuncu
    'yellow',   -- Sarı
    'lime',     -- Lime Yeşil
    'indigo',   -- İndigo
    'gray',     -- Gri
    'gold',     -- Altın
    'silver'    -- Gümüş
}

-- Varsayılan tema
Config.DefaultTheme = 'default'