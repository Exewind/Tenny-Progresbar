let progressActive = false;
let progressInterval = null;
let currentProgress = 0;
let totalBullets = 20;
let currentTheme = null;

// NUI mesajlarını dinle
window.addEventListener('message', function(event) {
    const data = event.data;
    
    switch(data.action) {
        case 'startProgress':
            startProgress(data.duration, data.text, data.theme);
            break;
        case 'stopProgress':
            stopProgress();
            break;
    }
});

function startProgress(duration, text, theme) {
    if (progressActive) return;
    
    progressActive = true;
    currentProgress = 0;
    currentTheme = theme;
    
    // UI elementlerini güncelle
    const progressText = document.getElementById('progressText');
    const progressPercent = document.getElementById('progressPercent');
    const progressContainer = document.getElementById('progressContainer');
    
    if (!progressText || !progressPercent || !progressContainer) {
        console.error('Progress bar elements not found');
        return;
    }
    
    progressText.textContent = text || 'Loading...';
    progressPercent.textContent = '0%';
    
    // CSS tema sınıfını uygula
    applyTheme(theme);
    
    // Bullets oluştur
    createBullets();
    
    // Container'ı göster
    progressContainer.classList.remove('hidden');
    
    // Progress animasyonunu başlat
    const updateInterval = 50; // 50ms intervals for smooth animation
    const totalUpdates = duration / updateInterval;
    const progressPerUpdate = 100 / totalUpdates;
    
    progressInterval = setInterval(() => {
        currentProgress += progressPerUpdate;
        
        if (currentProgress >= 100) {
            currentProgress = 100;
            updateProgress(currentProgress);
            setTimeout(() => {
                stopProgress();
                // FiveM'e progress tamamlandığını bildir
                fetch(`https://Tenny-Progresbar/progressFinished`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json; charset=UTF-8',
                    },
                    body: JSON.stringify({})
                }).catch(() => {});
            }, 500);
            return;
        }
        
        updateProgress(currentProgress);
    }, updateInterval);
}

function stopProgress() {
    if (!progressActive) return;
    
    progressActive = false;
    currentProgress = 0;
    
    if (progressInterval) {
        clearInterval(progressInterval);
        progressInterval = null;
    }
    
    // Container'ı gizle
    const progressContainer = document.getElementById('progressContainer');
    if (progressContainer) {
        progressContainer.classList.add('hidden');
    }
}

function createBullets() {
    const container = document.getElementById('bulletsContainer');
    if (!container) {
        console.error('Bullets container not found');
        return;
    }
    
    container.innerHTML = '';
    
    for (let i = 0; i < totalBullets; i++) {
        const bullet = document.createElement('div');
        bullet.className = 'bullet';
        bullet.setAttribute('data-index', i);
        container.appendChild(bullet);
    }
}

function updateProgress(progress) {
    // Yüzde göstergesini güncelle
    const progressPercent = document.getElementById('progressPercent');
    if (progressPercent) {
        progressPercent.textContent = Math.round(progress) + '%';
    }
    
    // Bullets'i güncelle
    const bullets = document.querySelectorAll('.bullet');
    
    // Daha doğru hesaplama: progress 100'de tam 20 ok dolu olacak
    const completedBullets = Math.floor((progress / 100) * totalBullets);
    const nextBulletProgress = ((progress / 100) * totalBullets) - completedBullets;
    
    bullets.forEach((bullet, index) => {
        if (bullet) {
            bullet.classList.remove('active', 'completed');
            
            if (index < completedBullets) {
                bullet.classList.add('completed');
            } else if (index === completedBullets && progress < 100 && nextBulletProgress > 0) {
                bullet.classList.add('active');
            }
        }
    });
}

// CSS tema sınıfını uygula
function applyTheme(theme) {
    const progressContainer = document.getElementById('progressContainer');
    if (progressContainer && theme) {
        // Önceki tema sınıflarını temizle
        progressContainer.className = progressContainer.className.replace(/theme-\w+/g, '');
        // Yeni tema sınıfını ekle
        progressContainer.classList.add('theme-' + theme);
    }
}

// ESC tuşu ile iptal etme
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && progressActive) {
        stopProgress();
        // FiveM'e iptal edildiğini bildir
        fetch(`https://Tenny-Progresbar/progressCancelled`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
            },
            body: JSON.stringify({})
        }).catch(() => {});
    }
});

// GetParentResourceName fonksiyonu (FiveM dışında test için)
function GetParentResourceName() {
    return 'Tenny-Progresbar';
}