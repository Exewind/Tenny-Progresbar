local isProgressActive = false

-- Progress bar başlatma fonksiyonu (otomatik tema)
function StartProgress(duration, text, onFinish, onCancel, theme)
    if isProgressActive then
        return false
    end
    
    isProgressActive = true
    
    -- Tema ismini al (tema verilmezse config'den otomatik al)
    local selectedTheme = theme or Config.DefaultTheme
    
    -- UI'yi göster
    SetNuiFocus(false, false)
    SendNUIMessage({
        action = "startProgress",
        duration = duration,
        text = text or "Loading...",
        theme = selectedTheme
    })
    
    -- Progress süresince kontrolleri devre dışı bırak
    CreateThread(function()
        while isProgressActive do
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true) -- Mouse look
            EnableControlAction(0, 2, true) -- Mouse look
            Wait(0)
        end
    end)
    
    -- İptal kontrolü
    CreateThread(function()
        while isProgressActive do
            if IsControlJustPressed(0, 73) then -- X tuşu
                StopProgress()
                if onCancel then
                    onCancel()
                end
                break
            end
            Wait(0)
        end
    end)
    
    -- Otomatik bitirme
    SetTimeout(duration, function()
        if isProgressActive then
            StopProgress()
            if onFinish then
                onFinish()
            end
        end
    end)
    
    return true
end

-- Progress bar durdurma fonksiyonu
function StopProgress()
    if not isProgressActive then
        return false
    end
    
    isProgressActive = false
    
    SendNUIMessage({
        action = "stopProgress"
    })
    
    return true
end

-- Export fonksiyonları
exports('StartProgress', StartProgress)
exports('StopProgress', StopProgress)

-- NUI Callbacks
RegisterNUICallback('progressFinished', function(data, cb)
    isProgressActive = false
    cb('ok')
end)

RegisterNUICallback('progressCancelled', function(data, cb)
    isProgressActive = false
    cb('ok')
end)

-- Test komutları (otomatik tema)
RegisterCommand('testprogress', function()
    StartProgress(5000, "Loading Bullets", function()
        print("Progress tamamlandı!")
    end, function()
        print("Progress iptal edildi!")
    end)
end)

RegisterCommand('testweed', function()
    StartProgress(10000, "Kenevir Toplanıyor...", function()
        print("Kenevir toplama tamamlandı!")
    end, function()
        print("Kenevir toplama iptal edildi!")
    end)
end)

RegisterCommand('testorange', function()
    StartProgress(5000, "Portakal Toplanıyor...", function()
        print("Portakal toplama tamamlandı!")
    end, function()
        print("Portakal toplama iptal edildi!")
    end)
end)

-- Renk testi komutları
RegisterCommand('testpink', function()
    StartProgress(3000, "Pembe Tema Test", nil, nil, 'pink')
end)

RegisterCommand('testblue', function()
    StartProgress(3000, "Mavi Tema Test", nil, nil, 'blue')
end)

RegisterCommand('testcyan', function()
    StartProgress(3000, "Cyan Tema Test", nil, nil, 'cyan')
end)

RegisterCommand('testpurple', function()
    StartProgress(3000, "Mor Tema Test", nil, nil, 'purple')
end)

RegisterCommand('testwhite', function()
    StartProgress(3000, "Beyaz Tema Test", nil, nil, 'white')
end)

RegisterCommand('testred', function()
    StartProgress(3000, "Kırmızı Tema Test", nil, nil, 'red')
end)

RegisterCommand('testorangetheme', function()
    StartProgress(3000, "Turuncu Tema Test", nil, nil, 'orange')
end)

RegisterCommand('testyellow', function()
    StartProgress(3000, "Sarı Tema Test", nil, nil, 'yellow')
end)

RegisterCommand('testlime', function()
    StartProgress(3000, "Lime Tema Test", nil, nil, 'lime')
end)

RegisterCommand('testindigo', function()
    StartProgress(3000, "İndigo Tema Test", nil, nil, 'indigo')
end)

RegisterCommand('testgray', function()
    StartProgress(3000, "Gri Tema Test", nil, nil, 'gray')
end)

RegisterCommand('testgold', function()
    StartProgress(3000, "Altın Tema Test", nil, nil, 'gold')
end)

RegisterCommand('testsilver', function()
    StartProgress(3000, "Gümüş Tema Test", nil, nil, 'silver')
end)